create function pg_catalog.round(numeric) returns numeric
LANGUAGE SQL
AS $$
select pg_catalog.round($1,0)
$$;
