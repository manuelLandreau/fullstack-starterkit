create function pg_catalog."overlaps"(time without time zone, time without time zone, time without time zone, interval) returns boolean
LANGUAGE SQL
AS $$
select ($1, $2) overlaps ($3, ($3 + $4))
$$;
